//Pareera Uqaily - puqaily@andrew.cmu.edu
package web;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import jakarta.servlet.*;
import java.io.IOException;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet
{
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException
    {
        // sends requests to dashboard
        req.getRequestDispatcher("/dashboard.jsp").forward(req, resp);
    }
}
