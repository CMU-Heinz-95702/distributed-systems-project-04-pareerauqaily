//Pareera Uqaily - puqaily@andrew.cmu.edu
package web;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/search")
public class BookSearchServlet extends HttpServlet
{
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException
    {
        // extracts parameters from the request
        String title = req.getParameter("title");
        String model = req.getParameter("model");
        String bookTitle = (title != null && !title.isEmpty()) ? title : "Unknown Title";
        String author = "Not Found";

        //URL construction
        String apiUrl = "https://openlibrary.org/search.json?title=" + java.net.URLEncoder.encode(bookTitle, "UTF-8");

        long startTime = System.currentTimeMillis();
        try
        {
            // HTTP connection to API
            java.net.URL url = new java.net.URL(apiUrl);
            java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            //parses json if response is ok
            if (conn.getResponseCode() == 200)
            {
                java.io.InputStream is = conn.getInputStream();
                java.util.Scanner s = new java.util.Scanner(is).useDelimiter("\\A");
                String json = s.hasNext() ? s.next() : "";

                //extracts first result from json if available
                org.json.JSONObject obj = new org.json.JSONObject(json);
                if (obj.getInt("numFound") > 0)
                {
                    org.json.JSONObject firstDoc = obj.getJSONArray("docs").getJSONObject(0);
                    if (firstDoc.has("author_name"))
                    {
                        author = firstDoc.getJSONArray("author_name").getString(0);
                    }
                    if (firstDoc.has("title"))
                    {
                        bookTitle = firstDoc.getString("title");
                    }
                }
            }
        } catch (Exception e)
        {
            e.printStackTrace(); // Logs errors
        }
        long latency = System.currentTimeMillis() - startTime; //latency

        //Log to MongoDB
        String timestamp = java.time.Instant.now().toString();
        MongoLogger.logRequest(timestamp, model, title, apiUrl, latency, bookTitle, author);

        // Respond with JSON
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        String jsonResponse = String.format("{\"title\":\"%s\", \"author\":\"%s\"}", bookTitle, author);
        resp.getWriter().write(jsonResponse);
    }
}
