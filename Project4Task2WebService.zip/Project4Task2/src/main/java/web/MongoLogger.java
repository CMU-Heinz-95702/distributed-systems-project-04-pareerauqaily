// Pareera Uqaily - puqaily@andrew.cmu.edu
package web;

import com.mongodb.client.*;
import org.bson.Document;

public class MongoLogger
{
    //defines MongoDB URI string connecting to atlas cluster
    private static final String mongoUri = "mongodb+srv://puqaily:1o1qI6lkoZG1XzbM@librarycluster.umhu4.mongodb.net/?retryWrites=true&w=majority&appName=LibraryCluster";
    //creates MongoClient instance
    private static final MongoClient mongoClient = MongoClients.create(mongoUri);
    //retrieves libraryDB from client
    private static final MongoDatabase db = mongoClient.getDatabase("LibraryDB");
    //retrieves logs collection from database
    private static final MongoCollection<Document> logs = db.getCollection("logs");

    //logs  details to the MongoDB logs collection
    public static void logRequest(String timestamp, String phoneModel, String searchTitle,
                                  String apiUrl, long latency, String resultTitle, String resultAuthor)
    {

        // Creates document with the request and response information
        Document log = new Document("timestamp", timestamp)
                .append("phoneModel", phoneModel) //phone model info
                .append("searchTitle", searchTitle) //title of book
                .append("openLibraryUrl", apiUrl) // api Url
                .append("openLibraryLatencyMs", latency) //latency in ms
                .append("resultTitle", resultTitle) //title from api
                .append("resultAuthor", resultAuthor); // author from api

        // inserts into logs in MongoDB
        logs.insertOne(log);
    }
}
